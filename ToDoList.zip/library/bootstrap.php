<?php
    require_once (ROOT . DS . 'config' . DS . 'config.php');
    require_once (ROOT . DS . 'library' . DS . 'shared.php');