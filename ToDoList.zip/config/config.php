<?php

/** Configuration Variables **/

define ('DEVELOPMENT_ENVIRONMENT',true);

define('DB_NAME', 'emretalu_todolist');
define('DB_USER', 'emretalu_statix');
define('DB_PASSWORD', 'xander1987');
define('DB_HOST', 'localhost');